package hospital;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 * @author cspr
 *
 */
public class Test {
	static ArrayList<Doctor> doctorlist = new ArrayList<Doctor>(10);
	static ArrayList<Patient> patientlist = new ArrayList<Patient>(10);
	
	
	public static void printDoctor(ArrayList<Doctor> display) {
        for (int i = 0; i < display.size(); i++) {
        	System.out.print("SSN:");
        	System.out.println(display.get(i).SSN);
        	System.out.print("Name:");
            System.out.println(display.get(i).Name);
            System.out.print("Gender:");
            System.out.println(display.get(i).Gender);
            System.out.print("Date Of Birth:");
            System.out.println(display.get(i).DateOfBirth);
        }
    }
	public static void printPatient(ArrayList<Patient> display) {
        for (int i = 0; i < display.size(); i++) {
        	System.out.print("SSN:");
        	System.out.println(display.get(i).SSN);
        	System.out.print("Name:");
            System.out.println(display.get(i).Name);
            System.out.print("Gender:");
            System.out.println(display.get(i).Gender);
            System.out.print("Date Of Birth:");
            System.out.println(display.get(i).DateOfBirth);
        }
    }
	public static void addDoctor(Doctor Doc) {
		doctorlist.add(Doc);
	}
	public static void listDoctor(){
		printDoctor(doctorlist);
	}
	public static void deleteDoctor() {
		System.out.println("SSN:");
		
	}
	public static void getDoctorDetails() {
		System.out.println("SSN:");
	}
	public static void addPatient(Patient Pat) {
		patientlist.add(Pat);
	}
	public static void listPatient() {
		printPatient(patientlist);
	}
	public static void deletePatient() {
		System.out.println("SSN:");
	}
	public static void getPatientDetails() {
		System.out.println("SSN:");
	}
}