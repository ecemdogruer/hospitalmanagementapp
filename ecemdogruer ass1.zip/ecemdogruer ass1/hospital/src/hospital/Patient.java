package hospital;

public class Patient {
	public int SSN;
	public String Name;
	public String Gender;
	public String DateOfBirth;
	
	Patient(int ssn,String name, String gender,String dob)
	{
	    this.SSN=ssn;
	    this.Name=name;
	    this.Gender=gender;
	    this.DateOfBirth=dob;

	}
	
}
