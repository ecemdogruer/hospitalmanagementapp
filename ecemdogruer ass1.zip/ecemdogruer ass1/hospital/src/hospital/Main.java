package hospital;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int choice;
		System.out.println("Hospital Management System\n");
		do {
		menu();
		System.out.println("Select:");
		choice = input.nextInt();
		if(choice == 1) {
			System.out.println("\nNew Doctor Info\n");
			System.out.println("SSN:");
			int ssn = input.nextInt();
			System.out.println("Name:");
			String name = input.next();
			System.out.println("Gender(F/M):");
			String gender = input.next();
			System.out.println("Date Of Birth:");
			String dob = input.next();
			Doctor doc = new Doctor(ssn,name,gender,dob);
			Test.addDoctor(doc);
		}
		else if(choice == 2) {
			Test.deleteDoctor();
		}
		else if(choice == 3) {
			Test.getDoctorDetails();
		}
		else if(choice == 4) {
			System.out.println("\nNew Patient Info\n");
			System.out.println("SSN:");
			int ssn = input.nextInt();
			System.out.println("Name:");
			String name = input.next();
			System.out.println("Gender(F/M):");
			String gender = input.next();
			System.out.println("Date Of Birth:");
			String dob = input.next();
			Patient pat = new Patient(ssn,name,gender,dob);
			Test.addPatient(pat);
		}
		else if(choice == 5) {
			Test.deletePatient();
		}
		else if(choice == 6) {
			Test.getPatientDetails();
		}
		else if(choice == 7) {
			Test.listDoctor();
		}
		else if(choice == 8) {
			Test.listPatient();
		}
		else if(choice == 9) {
			System.out.println("Bye!");
			return;
		}	
		else {
			System.out.println("ERROR:There is no option "+choice+"!");
		}
		}while(choice != 9);
		
}
	public static void menu() {
		System.out.println("(1)Add Doctor\n(2)Delete Doctor\n(3)Get Doctor Details");
		System.out.println("(4)Add Patient\n(5)Delete Patient\n(6)Get Patient Details");
		System.out.println("(7)List Doctors\n(8)List Patients\n(9)Quit\n");
	}

}
