package hospital;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.ArrayList;
public class Doctor {
	public int SSN;
	public String Name;
	public String Gender;
	public String DateOfBirth;
	
	Doctor(int ssn,String name, String gender,String dob)
	{
	    this.SSN=ssn;
	    this.Name=name;
	    this.Gender=gender;
	    this.DateOfBirth=dob;

	}
}

